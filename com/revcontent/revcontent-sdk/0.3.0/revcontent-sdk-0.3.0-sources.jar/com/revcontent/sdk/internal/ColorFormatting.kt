package com.revcontent.sdk.internal

/**
 * Formats the RGB channels of an ARGB int as a CSS "#RRGGBB" string.
 * Alpha is dropped — WebView transparency is carried by setBackgroundColor,
 * not the document body color.
 */
internal fun Int.toCssHex(): String = String.format("#%06X", 0xFFFFFF and this)
