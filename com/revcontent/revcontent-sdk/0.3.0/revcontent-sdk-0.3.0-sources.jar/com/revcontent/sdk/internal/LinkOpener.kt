package com.revcontent.sdk.internal

import android.content.Context
import android.content.Intent
import androidx.browser.customtabs.CustomTabsIntent
import androidx.core.net.toUri


/**
 * Opens [url] in an in-app Chrome Custom Tab — an overlay rendered by the user's
 * default browser, with a close button that returns to the host app. Custom Tabs
 * itself falls back to a plain ACTION_VIEW if no CCT-capable browser is installed;
 * if no browser at all is installed the launch is a no-op.
 *
 * The launching Context may be the Application context (e.g. when called from a
 * library WebView), in which case NEW_TASK is required.
 */
internal fun openLinkInCustomTab(context: Context, url: String) {
    val intent = CustomTabsIntent.Builder().build().apply {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
    intent.launchUrl(context, url.toUri())
}
