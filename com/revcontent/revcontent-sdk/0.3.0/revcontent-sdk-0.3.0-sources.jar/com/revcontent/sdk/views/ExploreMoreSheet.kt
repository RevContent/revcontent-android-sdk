package com.revcontent.sdk.views

import android.content.Context
import android.graphics.drawable.ColorDrawable
import android.view.LayoutInflater
import android.view.View
import android.widget.FrameLayout
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.shape.MaterialShapeDrawable
import com.revcontent.sdk.ExploreMoreSheetFactory
import com.revcontent.sdk.ExploreMoreSheetHandle
import com.revcontent.sdk.databinding.SheetExploreMoreBinding
import com.revcontent.sdk.internal.openLinkInCustomTab
import com.revcontent.sdk.internal.toCssHex
import com.revcontent.sdk.models.ExploreMoreConfig
import com.revcontent.sdk.services.RevcontentScrollTracker

/**
 * Bottom sheet that presents the Explore More widget
 * Mirrors iOS ExploreMoreOverlayView
 */
class ExploreMoreSheet(
    context: Context,
    private val config: ExploreMoreConfig,
    private val publisherId: String,
    private val siteUrl: String,
    private val onDismiss: () -> Unit,
    private val onArticleClick: () -> Unit
) {
    private val dialog = BottomSheetDialog(context)

    fun show() {
        val binding = SheetExploreMoreBinding.inflate(LayoutInflater.from(dialog.context))

        binding.exploreMoreTitle.text = config.title
        binding.exploreMoreClose.setOnClickListener {
            dialog.dismiss()
        }

        val widgetView = RevcontentWebView(dialog.context)

        val params = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        )
        widgetView.layoutParams = params
        widgetView.isNestedScrollingEnabled = true

        var widgetLoaded = false

        val tracker = RevcontentScrollTracker(dialog.context, widgetView)
        val density = dialog.context.resources.displayMetrics.density

        widgetView.addOnLayoutChangeListener { _, _, top, _, bottom, _, _, _, _ ->
            tracker.updateViewportHeight((bottom - top) / density)
        }

        widgetView.onHeightChanged = { height ->
            tracker.updateViewRect(
                x = 0f,
                y = 0f,
                width = widgetView.width / density,
                height = height
            )
            // Emit an initial scroll event so the JS sees a valid position before
            // the user scrolls; onHeightChanged fires from inside the bundle's own
            // DOMContentLoaded handler, so its listener is already attached.
            tracker.onScroll(widgetView.scrollY.toFloat())
            if (height > 0 && !widgetLoaded) {
                widgetLoaded = true
                binding.exploreMoreProgress.post {
                    binding.exploreMoreProgress.visibility = View.GONE
                    dialog.behavior.isDraggable = true
                }
            }
        }

        widgetView.onLinkClicked = { url ->
            openLinkInCustomTab(dialog.context, url)
            onArticleClick()
        }

        widgetView.onScrollChange = { scrollY ->
            if (widgetLoaded) {
                dialog.behavior.isDraggable = (scrollY == 0)
            }
            tracker.onScroll(scrollY.toFloat())
        }

        // Add the WebView to the container now, but defer loadWidget() until after
        // dialog.show() so we can read the sheet's real (elevation-composited) surface
        // color and bake it into the document HTML — no post-load JS patching needed.
        binding.exploreMoreContainer.addView(widgetView)
        binding.exploreMoreContainer.visibility = View.VISIBLE

        dialog.setContentView(binding.root)

        dialog.setOnDismissListener {
            onDismiss()
        }

        dialog.show()

        val displayMetrics = dialog.context.resources.displayMetrics
        val sheetHeight = (displayMetrics.heightPixels * 0.90).toInt()

        // The sheet view and its MaterialShapeDrawable background only exist after show().
        val sheetView = dialog.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)
        sheetView?.let { sheet ->
            sheet.layoutParams?.height = sheetHeight
            sheet.requestLayout()
        }

        if (sheetView != null) {
            // Defer the background read: MaterialShapeDrawable's resolvedTintColor isn't
            // assigned synchronously after show(), so we read after a layout pass.
            sheetView.post {
                val sheetColor = sheetView.resolvedBackgroundColorHex()
                widgetView.loadWidget(config.widgetId, publisherId, siteUrl, sheetColor)
            }
        } else {
            // Without a sheet view there's nothing to color-match; load transparent.
            widgetView.loadWidget(config.widgetId, publisherId, siteUrl, null)
        }

        // Force expanded, disable dragging until widget has settled
        dialog.behavior.apply {
            state = BottomSheetBehavior.STATE_EXPANDED
            skipCollapsed = true
            isDraggable = false
        }
    }

    fun dismiss() {
        dialog.dismiss()
    }

    fun isShowing(): Boolean = dialog.isShowing
}

/**
 * The production [ExploreMoreSheetFactory] behind
 * [com.revcontent.sdk.RevcontentExploreMore.presentIfNeeded].
 *
 * Deliberately lives here rather than next to the object it serves: `RevcontentExploreMore.kt`
 * is inside the JaCoCo denominator, and this function is pure Android wiring — build a
 * [ExploreMoreSheet], adapt it to the handle interface. This file is already excluded from
 * coverage as UI glue, so the construction sits behind the same exclusion.
 *
 * `onArticleClick` is a no-op because the imperative path marks the frequency cap at
 * presentation, not at dismissal — by the time a link is tapped there is nothing left to mark.
 */
internal val defaultExploreMoreSheetFactory = ExploreMoreSheetFactory {
        activity, config, publisherId, siteUrl, onDismiss ->
    val sheet = ExploreMoreSheet(
        context = activity,
        config = config,
        publisherId = publisherId,
        siteUrl = siteUrl,
        onDismiss = onDismiss,
        onArticleClick = {}
    )
    object : ExploreMoreSheetHandle {
        override fun show() = sheet.show()
        override fun dismiss() = sheet.dismiss()
    }
}

/**
 * Reads the resolved background color of a view as a CSS #RRGGBB string.
 * Handles MaterialShapeDrawable (the BottomSheet's background, which carries the
 * elevation-composited surface color via resolvedTintColor) and plain ColorDrawable.
 * Returns null if the background isn't a recognized colored drawable.
 */
private fun View.resolvedBackgroundColorHex(): String? {
    val color = when (val bg = background) {
        is MaterialShapeDrawable -> bg.resolvedTintColor
        is ColorDrawable -> bg.color
        else -> null
    } ?: return null
    return color.toCssHex()
}