package com.revcontent.sdk.internal

import android.util.Log
import androidx.annotation.VisibleForTesting
import com.revcontent.sdk.logging.LogLevel
import com.revcontent.sdk.logging.SdkLog
import java.util.Collections
import java.util.concurrent.ConcurrentHashMap

/**
 * Always-visible warnings for integration mistakes the SDK can detect at runtime —
 * setup the publisher has to fix, not routine SDK chatter.
 *
 * Deliberately does **not** go through [SdkLog] alone. That facade is silent until an
 * integrator attaches a [com.revcontent.sdk.logging.RevcontentLogger], which means a
 * missing-scroll-context warning would be invisible to exactly the publishers who need
 * to see it. So: deliver to the configured sink when there is one, and fall back to
 * Logcat when there isn't. The sink path also bypasses [SdkLog.minLevel] — these are
 * setup errors, not verbosity the integrator opted out of.
 */
internal object IntegrationDiagnostics {

    // Collections.newSetFromMap rather than ConcurrentHashMap.newKeySet(): the latter is
    // API 24+, and this module's minSdk is 21 with no core library desugaring, so it would
    // throw NoSuchMethodError on API 21-23 — from a diagnostics helper, of all things.
    private val emitted: MutableSet<String> =
        Collections.newSetFromMap(ConcurrentHashMap<String, Boolean>())

    /**
     * Emits [message] once per distinct [key] for the process lifetime. Callers fire from
     * layout/composition callbacks that run repeatedly, so deduping is what keeps a real
     * warning from becoming scrollback noise.
     */
    fun warnOnce(key: String, message: () -> String) {
        if (!emitted.add(key)) return

        val text = message()
        val sink = SdkLog.logger
        if (sink != null) {
            sink.log(LogLevel.WARN, SdkLog.tag, text, null)
        } else {
            Log.w(SdkLog.tag, text)
        }
    }

    /** Clears the once-per-key state so tests can assert on repeat emissions. */
    @VisibleForTesting
    internal fun reset() {
        emitted.clear()
    }
}
