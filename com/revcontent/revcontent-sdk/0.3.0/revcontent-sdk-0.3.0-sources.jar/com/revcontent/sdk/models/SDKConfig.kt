package com.revcontent.sdk.models

import org.json.JSONObject

/**
 * Remote configuration for the Revcontent SDK
 */
data class SDKConfig(
    val exploreMoreEnabled: Boolean,
    val exploreMoreConfig: ExploreMoreConfig?
) {
    companion object {
        val default = SDKConfig(
            exploreMoreEnabled = false,
            exploreMoreConfig = null
        )

        fun fromJson(json: JSONObject): SDKConfig {
            val exploreMoreEnabled = json.optBoolean("exploreMoreEnabled", false)
            val exploreMoreConfig = if (json.has("exploreMoreConfig")) {
                ExploreMoreConfig.fromJson(json.getJSONObject("exploreMoreConfig"))
            } else null

            return SDKConfig(
                exploreMoreEnabled = exploreMoreEnabled,
                exploreMoreConfig = exploreMoreConfig
            )
        }
    }
}