package com.revcontent.sdk.services

import com.revcontent.sdk.logging.SdkLog
import com.revcontent.sdk.models.SDKConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap

/**
 * A single config HTTP response: the status code and the (optional) body.
 * [body] is only populated for successful (2xx) responses.
 */
internal data class ConfigHttpResponse(val code: Int, val body: String?)

/**
 * Seam over the network so [ConfigService] can be exercised without real I/O.
 * The production implementation is [UrlConnectionConfigHttpClient]; tests inject
 * a fake. Implementations should throw on transport failure (timeout, DNS, …)
 * so the service's catch-all fallback path is exercised.
 */
internal fun interface ConfigHttpClient {
    fun get(url: String): ConfigHttpResponse
}

/** Default [ConfigHttpClient] backed by [HttpURLConnection]. */
internal object UrlConnectionConfigHttpClient : ConfigHttpClient {
    private const val CONNECT_TIMEOUT_MS = 5000
    private const val READ_TIMEOUT_MS = 5000

    override fun get(url: String): ConfigHttpResponse {
        var connection: HttpURLConnection? = null
        return try {
            connection = (URL(url).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = CONNECT_TIMEOUT_MS
                readTimeout = READ_TIMEOUT_MS
                setRequestProperty("Accept", "application/json")
            }
            val code = connection.responseCode
            val body = if (code == HttpURLConnection.HTTP_OK) {
                connection.inputStream.bufferedReader().use { it.readText() }
            } else {
                null
            }
            ConfigHttpResponse(code, body)
        } finally {
            connection?.disconnect()
        }
    }
}

/**
 * Fetches and caches remote SDK configuration.
 *
 * Caching policy:
 *  - A successful fetch is cached for [CACHE_EXPIRATION_MS] and served
 *    stale-while-revalidate (a background refresh is kicked off on read).
 *  - A failed fetch falls back to [SDKConfig.default] and is cached for the
 *    shorter [FAILURE_BACKOFF_MS] so a transient outage retries quickly.
 *
 * The network and clock are injected ([httpClient], [now]) so the policy is
 * unit-testable without real I/O or wall-clock waits.
 */
class ConfigService internal constructor(
    private val httpClient: ConfigHttpClient = UrlConnectionConfigHttpClient,
    private val now: () -> Long = System::currentTimeMillis,
    private val scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
) {

    private data class CachedConfig(
        val config: SDKConfig,
        val timestamp: Long,
        val isFallback: Boolean
    )

    private val cache = ConcurrentHashMap<String, CachedConfig>()

    private fun CachedConfig.isExpired(): Boolean {
        val ttl = if (isFallback) FAILURE_BACKOFF_MS else CACHE_EXPIRATION_MS
        return now() - timestamp > ttl
    }

    companion object {
        private const val CACHE_EXPIRATION_MS = 60L * 60L * 1000L // 1 hour
        private const val FAILURE_BACKOFF_MS = 60L * 1000L // 1 minute backoff on failure
        private const val CONFIG_URL = "https://delivery.revcontent.com"

        @Volatile
        private var instance: ConfigService? = null

        fun getInstance(): ConfigService {
            return instance ?: synchronized(this) {
                instance ?: ConfigService().also { instance = it }
            }
        }

        /** Builds an isolated instance with injected collaborators, for tests. */
        internal fun createForTesting(
            httpClient: ConfigHttpClient,
            now: () -> Long = System::currentTimeMillis,
            scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        ): ConfigService = ConfigService(httpClient, now, scope)
    }

    suspend fun getConfig(publisherId: String, widgetId: String): SDKConfig {
        val cacheKey = cacheKey(publisherId, widgetId)

        val cached = cache[cacheKey]
        if (cached != null && !cached.isExpired()) {
            if (!cached.isFallback) {
                // Stale-while-revalidate: refresh in background for next time
                scope.launch { fetchConfig(publisherId, widgetId) }
            }
            return cached.config
        }

        return fetchConfig(publisherId, widgetId)
    }

    private fun fetchConfig(publisherId: String, widgetId: String): SDKConfig {
        val cacheKey = cacheKey(publisherId, widgetId)
        return try {
            val response = httpClient.get("$CONFIG_URL/$publisherId/$widgetId")
            if (response.code == HttpURLConnection.HTTP_OK && response.body != null) {
                val config = SDKConfig.fromJson(JSONObject(response.body))
                cache[cacheKey] = CachedConfig(config, now(), isFallback = false)
                config
            } else {
                SdkLog.w { "Config fetch failed (${response.code}), using default" }
                cacheFallback(cacheKey)
            }
        } catch (e: Exception) {
            SdkLog.w(e) { "Error fetching config: ${e.message}, using default" }
            cacheFallback(cacheKey)
        }
    }

    private fun cacheFallback(cacheKey: String): SDKConfig {
        cache[cacheKey] = CachedConfig(SDKConfig.default, now(), isFallback = true)
        return SDKConfig.default
    }

    private fun cacheKey(publisherId: String, widgetId: String) = "${publisherId}_${widgetId}"

    fun clearCache() {
        cache.clear()
    }
}
