package com.revcontent.sdk.compose

import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.findRootCoordinates
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import com.revcontent.sdk.services.RevcontentScrollTracker
import com.revcontent.sdk.views.RevcontentWebView

/**
 * Internal compose-facing scroll tracker state. Public callers use
 * [com.revcontent.sdk.compose.RevcontentWidget], which wires this up internally.
 */
internal class RevcontentScrollTrackerState internal constructor(
    val scrollState: ScrollState,
    internal val tracker: RevcontentScrollTracker,
    internal val density: Float
)

internal fun Modifier.revcontentScrollTracker(state: RevcontentScrollTrackerState): Modifier =
    onGloballyPositioned { coordinates ->
        val positionInRoot = coordinates.positionInRoot()
        state.tracker.updateViewRect(
            x = positionInRoot.x / state.density,
            y = (positionInRoot.y + state.scrollState.value) / state.density,
            width = coordinates.size.width / state.density,
            height = coordinates.size.height / state.density
        )
        // Root composable size as a proxy for the scroll container's viewport.
        // Accurate when the scroll container fills the host view (the common case).
        state.tracker.updateViewportHeight(
            coordinates.findRootCoordinates().size.height / state.density
        )
    }

@Composable
internal fun rememberRevcontentScrollTracker(
    webView: RevcontentWebView,
    scrollState: ScrollState = rememberScrollState(),
    throttleMs: Long = 100L
): RevcontentScrollTrackerState {
    val context = LocalContext.current
    val density = LocalDensity.current.density

    val tracker = remember(webView, throttleMs) {
        RevcontentScrollTracker(
            context = context,
            webView = webView,
            throttleMs = throttleMs
        )
    }

    val state = remember(tracker, scrollState, density) {
        RevcontentScrollTrackerState(
            scrollState = scrollState,
            tracker = tracker,
            density = density
        )
    }

    // snapshotFlow runs once per (tracker, scrollState) pair and emits on each state
    // change — cheaper than re-keying a LaunchedEffect on the position itself, which
    // would relaunch the coroutine on every pixel of scroll.
    LaunchedEffect(tracker, scrollState) {
        snapshotFlow { scrollState.value }
            .collect { tracker.onScroll(it.toFloat()) }
    }

    return state
}
