package com.revcontent.sdk.compose

import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.LocalActivity
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.lifecycle.lifecycleScope
import com.revcontent.sdk.Revcontent
import com.revcontent.sdk.internal.shouldShowExploreMore
import com.revcontent.sdk.logging.SdkLog
import com.revcontent.sdk.models.ExploreMoreConfig
import com.revcontent.sdk.models.FrequencyCapping
import com.revcontent.sdk.services.ExploreMoreFrequencyManager
import com.revcontent.sdk.views.ExploreMoreSheet
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private const val SHEET_DISMISS_ANIMATION_MS = 150L

/**
 * Wraps an article screen with Revcontent's back-press interception and
 * "Explore More" bottom-sheet behavior.
 *
 *     RevcontentArticleScaffold(
 *         articleUrl = currentArticleUrl,
 *         exploreMore = ExploreMoreConfig(
 *             widgetId = "286827",
 *             frequencyCapping = FrequencyCapping.OncePerArticle
 *         ),
 *         onNavigateBack = { navController.popBackStack() }
 *     ) {
 *         // your article body
 *     }
 *
 * The back-press callback registers/unregisters automatically with the composable's
 * lifecycle, so there's no setup or teardown required.
 *
 * @param onNavigateBack Invoked when the user navigates back (either directly when
 *   there's no explore-more config, or after the explore-more sheet is dismissed).
 * @param articleUrl Used for [FrequencyCapping.OncePerArticle]. If null and that
 *   capping is configured, the sheet falls back to showing once per scaffold instance.
 * @param exploreMore Optional explore-more configuration. If null, back press just
 *   calls [onNavigateBack].
 * @param publisherId Optional override for [Revcontent.publisherId].
 * @param siteUrl Optional override for [Revcontent.siteUrl].
 * @param content The article body.
 */
@Composable
fun RevcontentArticleScaffold(
    onNavigateBack: () -> Unit,
    articleUrl: String? = null,
    exploreMore: ExploreMoreConfig? = null,
    publisherId: String = Revcontent.publisherId,
    siteUrl: String = Revcontent.siteUrl,
    content: @Composable () -> Unit
) {
    val activity = LocalActivity.current as? ComponentActivity
        ?: error("RevcontentArticleScaffold must be hosted inside a ComponentActivity.")
    val frequencyManager = remember(activity) {
        ExploreMoreFrequencyManager.getInstance(activity)
    }

    val currentOnNavigateBack by rememberUpdatedState(onNavigateBack)
    val currentExploreMore by rememberUpdatedState(exploreMore)
    val currentArticleUrl by rememberUpdatedState(articleUrl)

    DisposableEffect(activity) {
        if (exploreMore?.frequencyCapping is FrequencyCapping.OncePerArticle && articleUrl == null) {
            SdkLog.w {
                "OncePerArticle requested but no articleUrl provided; falling back to once per " +
                    "scaffold instance. Pass articleUrl to cap per article across the session."
            }
        }

        var activeSheet: ExploreMoreSheet? = null
        // Fallback identity for OncePerArticle when no articleUrl is supplied: this scaffold
        // instance lives as long as the article screen does, so "already shown here" is a
        // reasonable stand-in. Scoped to the DisposableEffect, so a new screen starts fresh.
        var hasShownInThisArticle = false

        val callback = object : OnBackPressedCallback(enabled = true) {
            override fun handleOnBackPressed() {
                val config = currentExploreMore
                val shouldShow = config != null && shouldShowExploreMore(
                    config = config,
                    articleUrl = currentArticleUrl,
                    state = frequencyManager,
                    isSheetShowing = activeSheet?.isShowing() == true,
                    hasShownInThisInstance = hasShownInThisArticle
                )
                if (!shouldShow) {
                    isEnabled = false
                    currentOnNavigateBack()
                    return
                }
                hasShownInThisArticle = true
                activeSheet = ExploreMoreSheet(
                    context = activity,
                    config = config!!,
                    publisherId = publisherId,
                    siteUrl = siteUrl,
                    onDismiss = {
                        activeSheet = null
                        frequencyManager.markShown(currentArticleUrl)
                        activity.lifecycleScope.launch {
                            delay(SHEET_DISMISS_ANIMATION_MS)
                            isEnabled = false
                            currentOnNavigateBack()
                        }
                    },
                    onArticleClick = {
                        frequencyManager.markShown(currentArticleUrl)
                    }
                ).also { it.show() }
            }
        }

        activity.onBackPressedDispatcher.addCallback(activity, callback)
        onDispose {
            callback.remove()
            activeSheet?.dismiss()
        }
    }

    content()
}
