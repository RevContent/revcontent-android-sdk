package com.revcontent.sdk.internal

/** Escapes a value safely for use inside an HTML attribute (`"..."`). */
internal fun htmlAttrEscape(value: String): String = buildString(value.length) {
    for (c in value) when (c) {
        '&' -> append("&amp;")
        '<' -> append("&lt;")
        '>' -> append("&gt;")
        '"' -> append("&quot;")
        '\'' -> append("&#39;")
        else -> append(c)
    }
}

/**
 * Percent-encodes a value for use as a single URL path segment.
 * Conservative — preserves only RFC 3986 unreserved characters.
 */
internal fun urlPathEscape(value: String): String = buildString(value.length) {
    for (c in value) when {
        c.isLetterOrDigit() || c == '-' || c == '_' || c == '.' || c == '~' -> append(c)
        else -> append("%%%02X".format(c.code))
    }
}
