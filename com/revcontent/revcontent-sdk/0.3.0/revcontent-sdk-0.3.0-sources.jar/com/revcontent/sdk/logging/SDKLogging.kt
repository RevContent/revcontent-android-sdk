package com.revcontent.sdk.logging

import android.util.Log

/* =============================================================================
 *  Revcontent SDK logging — pluggable sink design
 *
 *  Split into separate files in a real project (LogLevel.kt, RevcontentLogger.kt,
 *  SdkLog.kt, LogcatLogger.kt). Grouped here for readability.
 *
 *  Integrators configure logging through [com.revcontent.sdk.Revcontent].
 * ============================================================================= */

/** Severity, ordered least -> most severe. Threshold check is `level >= minLevel`. */
enum class LogLevel {
    VERBOSE, DEBUG, INFO, WARN, ERROR
}

/**
 * The sink an integrator implements to receive the SDK's logs.
 *
 * Public, branded entry into the logging system: implement this (or pass a lambda,
 * since it's a `fun interface`) to route Revcontent's logs wherever you want —
 * Logcat, Timber, a file, a crash reporter, or nowhere.
 *
 * May be invoked from any thread; implementations should be cheap and thread-safe.
 */
fun interface RevcontentLogger {
    fun log(level: LogLevel, tag: String, message: String, throwable: Throwable?)
}

/**
 * Internal logging facade the SDK's own code calls (`SdkLog.d { ... }`).
 *
 * Deliberately NOT branded and NOT public: integrators configure logging through
 * [com.revcontent.sdk.Revcontent], never this. Default state is silent (no sink attached).
 */
internal object SdkLog {

    @Volatile
    var logger: RevcontentLogger? = null

    @Volatile
    var minLevel: LogLevel = LogLevel.DEBUG

    @Volatile
    var tag: String = "RevcontentSDK"

    inline fun v(throwable: Throwable? = null, message: () -> String) {
        val sink = logger
        if (sink != null && LogLevel.VERBOSE >= minLevel) {
            sink.log(LogLevel.VERBOSE, tag, message(), throwable)
        }
    }

    inline fun d(throwable: Throwable? = null, message: () -> String) {
        val sink = logger
        if (sink != null && LogLevel.DEBUG >= minLevel) {
            sink.log(LogLevel.DEBUG, tag, message(), throwable)
        }
    }

    inline fun i(throwable: Throwable? = null, message: () -> String) {
        val sink = logger
        if (sink != null && LogLevel.INFO >= minLevel) {
            sink.log(LogLevel.INFO, tag, message(), throwable)
        }
    }

    inline fun w(throwable: Throwable? = null, message: () -> String) {
        val sink = logger
        if (sink != null && LogLevel.WARN >= minLevel) {
            sink.log(LogLevel.WARN, tag, message(), throwable)
        }
    }

    inline fun e(throwable: Throwable? = null, message: () -> String) {
        val sink = logger
        if (sink != null && LogLevel.ERROR >= minLevel) {
            sink.log(LogLevel.ERROR, tag, message(), throwable)
        }
    }
}


/**
 * Batteries-included [RevcontentLogger] that routes to Logcat. Integrators who just
 * want the SDK's logs during development can opt in with:
 *
 *     Revcontent.configure(
 *         publisherId = "...",
 *         siteUrl = "...",
 *         logger = LogcatLogger,
 *     )
 */
object LogcatLogger : RevcontentLogger {
    override fun log(level: LogLevel, tag: String, message: String, throwable: Throwable?) {
        when (level) {
            LogLevel.VERBOSE -> Log.v(tag, message, throwable)
            LogLevel.DEBUG   -> Log.d(tag, message, throwable)
            LogLevel.INFO    -> Log.i(tag, message, throwable)
            LogLevel.WARN    -> Log.w(tag, message, throwable)
            LogLevel.ERROR   -> Log.e(tag, message, throwable)
        }
    }
}