package com.revcontent.sdk

import androidx.activity.ComponentActivity
import androidx.annotation.MainThread
import androidx.annotation.VisibleForTesting
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import com.revcontent.sdk.internal.ExploreMoreContinuation
import com.revcontent.sdk.internal.ExploreMoreGate
import com.revcontent.sdk.internal.IntegrationDiagnostics
import com.revcontent.sdk.internal.exploreMoreGate
import com.revcontent.sdk.logging.SdkLog
import com.revcontent.sdk.models.ExploreMoreConfig
import com.revcontent.sdk.models.FrequencyCapping
import com.revcontent.sdk.services.ExploreMoreFrequencyManager
import com.revcontent.sdk.views.defaultExploreMoreSheetFactory
import java.util.WeakHashMap

/**
 * Imperative Explore More entry point, for apps whose "back" is not a route pop.
 *
 * The counterpart to [com.revcontent.sdk.compose.RevcontentArticleScaffold] and
 * [RevcontentArticleHelper], which hook `OnBackPressedDispatcher` and complete by popping.
 * Reach for this one when going back is the app's *own* control — most often a single
 * long-lived `WebView` navigating in place, where "back" is a toolbar button calling
 * `WebView.goBack()` and there is no route to pop and no back button to replace.
 *
 * Note that an article rendered in a full-screen `WebView` does **not** by itself need this
 * API. Explore More triggers on the back *affordance*, never on the article's content, so a
 * WebView article pushed as its own screen already works with the scaffold or the helper,
 * unchanged. This is only for when back stops being a route pop.
 *
 * Works the same from either UI toolkit, since it takes an Activity rather than a
 * composable scope or a View:
 *
 *     // View-based Activity or Fragment
 *     RevcontentExploreMore.presentIfNeeded(
 *         activity = this,
 *         config = config,
 *         articleId = webView.url,
 *     ) { webView.goBack() }
 *
 *     // Compose
 *     val activity = LocalActivity.current as ComponentActivity
 *     RevcontentExploreMore.presentIfNeeded(activity, config, articleId = currentUrl) {
 *         webView.goBack()
 *     }
 *
 * Two things to decide on this surface. Pick the capping mode with care — see `articleId` —
 * and decide whether every back press should be able to prompt. If the reader can navigate
 * *within* your content (an in-place WebView), pass `isSurfaceExit = !webView.canGoBack()`
 * so only the press that actually leaves is a candidate.
 */
object RevcontentExploreMore {

    /**
     * Imperative presentations in flight, keyed by their host Activity — the Android stand-in
     * for the associated object iOS hangs off its view controller. Guards against stacking a
     * second sheet on an Activity that already has one up.
     *
     * The weak key is a backstop, not the cleanup mechanism: the value reaches the key
     * (the sheet holds the Activity as its `Context`), so this entry would never be collected
     * on its own. What actually keeps it clean is deterministic removal on both terminal
     * paths — completion and `ON_DESTROY`. The lifecycle observer is the leak fix.
     *
     * Scope limit: this sees only imperative presentations. The scaffold and helper keep
     * their sheet in a closure/private field that nothing else can reach, so an Activity
     * driving both paths could still stack sheets. An app whose back isn't a route pop has
     * no reason to also mount the scaffold.
     */
    private val active = WeakHashMap<ComponentActivity, ImperativePresentation>()

    /**
     * Test seam, mirroring [com.revcontent.sdk.services.RevcontentScrollTracker]'s
     * `clock`/`jsEmitter`: swap in a fake so JVM tests can drive the full flow without a real
     * `BottomSheetDialog`.
     *
     * Not because the real one is impossible under Robolectric — it presents fine, as
     * `RevcontentArticleHelperTest` demonstrates — but because a fake makes the assertions
     * direct. Tests can observe exactly when the sheet was built, shown, and dismissed, and
     * can force a presentation failure, none of which is reachable through a live dialog
     * carrying a real `RevcontentWebView`.
     */
    @VisibleForTesting
    internal var sheetFactory: ExploreMoreSheetFactory = defaultExploreMoreSheetFactory

    /**
     * Shows the Explore More sheet if frequency capping allows, then runs [onContinue].
     *
     * [onContinue] runs **exactly once, on the calling (main) thread**: after the sheet is
     * dismissed if one was shown, or immediately if not — the SDK is unconfigured, capping
     * declined, a sheet is already up, or presentation failed. Put your app's back action
     * there and nowhere else. Running it on every path is what stops frequency capping from
     * silently breaking your navigation.
     *
     * The one exception: if [activity] is destroyed while the sheet is up (rotation, process
     * death), the sheet is dismissed and [onContinue] is **dropped without running**, because
     * it would act on a WebView that no longer exists. The contract is therefore *exactly once
     * while [activity] is alive; at most once overall.* The frequency cap has already been
     * consumed by then, so the sheet does not immediately reappear on the next back tap — the
     * user lands back on the article with working chrome.
     *
     * Unlike the scaffold and the helper, this registers **no** back-press callback and
     * touches no back affordance, so the system back button and the predictive-back gesture
     * keep behaving exactly as your app defines them.
     *
     * @param activity Host for the bottom sheet. Its lifecycle bounds the presentation.
     * @param config Widget id, title, and frequency capping.
     * @param articleId Identity for [FrequencyCapping.OncePerArticle] — pass the article's
     *   URL. One Activity serves every article on this path, so a per-instance flag would
     *   never reset. Unlike the scaffold and helper there is no instance to fall back to, so
     *   without an id `OncePerArticle` cannot cap at all and logs a warning. Other
     *   capping modes ignore it, so passing it always is harmless.
     *
     *   Be deliberate about the capping mode here. [FrequencyCapping.OncePerArticle] caps
     *   **permanently** per URL, which on the surface this API exists for — one screen
     *   serving many URLs — means Explore More stops appearing for good once the reader has
     *   backed out of each page once. [FrequencyCapping.OncePerSession] or
     *   [FrequencyCapping.every] are usually what you want. See
     *   [FrequencyCapping.OncePerArticle] for the full warning.
     * @param isSurfaceExit Whether this back press is the reader *leaving* your content, as
     *   opposed to moving within it. Defaults to `true`, which suits a screen whose back
     *   press always means "done here".
     *
     *   Pass `!webView.canGoBack()` on an in-place WebView. In-page links push history
     *   entries rather than popping them — even ones labelled "back" — so a reader who taps
     *   two links is several entries deep, and consulting the SDK on every step would prompt
     *   them repeatedly on the way out. Passing `false` makes those mid-chain presses a
     *   no-op: [onContinue] runs immediately, no sheet, and **no frequency cap is spent**, so
     *   the one prompt you do want is still available when they finally leave.
     * @param publisherId Override for [Revcontent.publisherId]; null uses the configured value.
     * @param siteUrl Override for [Revcontent.siteUrl]; null uses the configured value.
     * @param onContinue Your app's own back action. See above for exactly when it runs.
     * @return Whether the sheet was presented, so you can skip animating your own transition
     *   underneath it.
     */
    @JvmStatic
    @MainThread
    fun presentIfNeeded(
        activity: ComponentActivity,
        config: ExploreMoreConfig,
        articleId: String? = null,
        isSurfaceExit: Boolean = true,
        publisherId: String? = null,
        siteUrl: String? = null,
        onContinue: () -> Unit
    ): Boolean {
        val continuation = ExploreMoreContinuation(onContinue)

        val gate = exploreMoreGate(
            isConfigured = Revcontent.isConfigured,
            isAlreadyPresenting = synchronized(active) { active[activity] } != null,
            isSurfaceExit = isSurfaceExit,
            config = config,
            articleId = articleId,
            state = ExploreMoreFrequencyManager.getInstance(activity)
        )

        if (gate != ExploreMoreGate.PRESENT) {
            logDeclined(gate, activity)
            continuation.complete()
            return false
        }

        // Reachable only from here: OncePerArticle without an id can't cap, so the gate
        // always says PRESENT for that misconfiguration rather than declining.
        warnIfArticleIdMissing(activity, config, articleId)

        // Safe to read the throwing getters: the gate above returned PRESENT, which means
        // isConfigured was true, and configure() only ever assigns non-null. Resolving them
        // here rather than as default arguments is load-bearing — a default is evaluated at
        // the *call site*, so `publisherId: String = Revcontent.publisherId` would throw
        // before the gate could run and the caller's back action would never happen.
        val presentation = ImperativePresentation(
            activity = activity,
            continuation = continuation,
            sheet = sheetFactory.create(
                activity = activity,
                config = config,
                publisherId = publisherId ?: Revcontent.publisherId,
                siteUrl = siteUrl ?: Revcontent.siteUrl,
                onDismiss = { onSheetDismissed(activity) }
            )
        )

        synchronized(active) { active[activity] = presentation }
        activity.lifecycle.addObserver(presentation)

        if (!presentation.show()) {
            // Presentation failed after the capping check — hand control straight back and
            // leave the cap alone, since nothing was shown.
            detach(activity, presentation)
            continuation.complete()
            return false
        }

        // Marked at presentation, not at dismissal like the back-press paths. That keeps the
        // ON_DESTROY path coherent: it dismisses with the continuation already abandoned, so a
        // dismiss-time mark would be skipped and a rotation would silently un-consume the cap.
        ExploreMoreFrequencyManager.getInstance(activity).markShown(articleId)
        return true
    }

    private fun onSheetDismissed(activity: ComponentActivity) {
        val presentation = synchronized(active) { active[activity] } ?: return
        detach(activity, presentation)
        presentation.continuation.complete()
    }

    private fun detach(activity: ComponentActivity, presentation: ImperativePresentation) {
        synchronized(active) { if (active[activity] === presentation) active.remove(activity) }
        activity.lifecycle.removeObserver(presentation)
    }

    private fun logDeclined(gate: ExploreMoreGate, activity: ComponentActivity) {
        when (gate) {
            ExploreMoreGate.NOT_CONFIGURED -> IntegrationDiagnostics.warnOnce(
                "explore-more-not-configured:${activity.javaClass.name}"
            ) {
                "RevcontentExploreMore.presentIfNeeded was called before Revcontent.configure(...), " +
                    "so no sheet can be shown and every back press falls straight through. " +
                    "Call Revcontent.configure(publisherId = ..., siteUrl = ...) from Application.onCreate()."
            }
            // A transient runtime condition rather than a setup mistake, so ordinary SdkLog.
            ExploreMoreGate.ALREADY_PRESENTING ->
                SdkLog.w { "Explore More skipped: a sheet is already showing on this activity." }
            ExploreMoreGate.CAPPED ->
                SdkLog.d { "Explore More skipped: frequency capping declined." }
            ExploreMoreGate.NOT_SURFACE_EXIT ->
                SdkLog.d { "Explore More skipped: caller reported this back press stays within its content." }
            ExploreMoreGate.PRESENT -> Unit
        }
    }

    /**
     * Keyed on the Activity class, never on the article id — ids are unbounded, and keying on
     * one would grow [IntegrationDiagnostics]' dedupe set without limit.
     */
    private fun warnIfArticleIdMissing(
        activity: ComponentActivity,
        config: ExploreMoreConfig,
        articleId: String?
    ) {
        if (config.frequencyCapping !is FrequencyCapping.OncePerArticle || articleId != null) return
        IntegrationDiagnostics.warnOnce("explore-more-missing-article-id:${activity.javaClass.name}") {
            "Explore More is configured for OncePerArticle but presentIfNeeded was called without " +
                "an articleId, so it cannot cap and the sheet will show on every back press. " +
                "One activity serves every article on this path, so pass the current article's URL:\n" +
                "    RevcontentExploreMore.presentIfNeeded(activity, config, articleId = webView.url) { ... }"
        }
    }

    /** Number of imperative presentations currently registered. Leak guard for tests. */
    @VisibleForTesting
    internal fun activePresentationCount(): Int = synchronized(active) { active.size }

    @VisibleForTesting
    internal fun resetForTesting() {
        synchronized(active) { active.clear() }
        sheetFactory = defaultExploreMoreSheetFactory
    }

    /**
     * One in-flight imperative presentation: the sheet, the caller's back action, and the
     * lifecycle hook that tears both down if the Activity goes away first.
     */
    private class ImperativePresentation(
        private val activity: ComponentActivity,
        val continuation: ExploreMoreContinuation,
        private val sheet: ExploreMoreSheetHandle
    ) : DefaultLifecycleObserver {

        /**
         * @return whether the sheet actually went up. `BottomSheetDialog.show()` throws
         *   `BadTokenException` on a finishing Activity and `CalledFromWrongThreadException`
         *   off the main thread; letting either escape would skip the caller's back action and
         *   strand them on the article, which is the exact failure this API exists to prevent.
         */
        fun show(): Boolean {
            if (activity.isFinishing || activity.isDestroyed) return false
            return try {
                sheet.show()
                true
            } catch (e: RuntimeException) {
                SdkLog.e(e) { "Explore More sheet failed to present; continuing with the host's back action." }
                false
            }
        }

        override fun onDestroy(owner: LifecycleOwner) {
            // Abandon *before* dismissing: the dismiss listener then finds nothing owed and
            // becomes a no-op, so no extra seam is needed on ExploreMoreSheet.
            detach(activity, this)
            continuation.abandon()
            sheet.dismiss()
        }
    }
}

/** The sheet, as much of it as the imperative path needs. Fakeable in tests. */
internal interface ExploreMoreSheetHandle {
    fun show()
    fun dismiss()
}

/**
 * Builds the sheet for one presentation. The production implementation is
 * [defaultExploreMoreSheetFactory], which lives in `views/ExploreMoreSheet.kt` so it lands
 * inside that file's JaCoCo exclusion — this file is in the coverage denominator, and wiring
 * up a live `BottomSheetDialog` is Android glue rather than policy worth covering here.
 */
internal fun interface ExploreMoreSheetFactory {
    fun create(
        activity: ComponentActivity,
        config: ExploreMoreConfig,
        publisherId: String,
        siteUrl: String,
        onDismiss: () -> Unit
    ): ExploreMoreSheetHandle
}
