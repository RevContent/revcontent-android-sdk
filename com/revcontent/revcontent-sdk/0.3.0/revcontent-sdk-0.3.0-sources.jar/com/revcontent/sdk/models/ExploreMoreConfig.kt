package com.revcontent.sdk.models

import org.json.JSONObject
import kotlin.time.Duration

/**
 * Configuration for the Explore More feature
 */
data class ExploreMoreConfig(
    val widgetId: String,
    val title: String = "Keep on reading",
    val frequencyCapping: FrequencyCapping? = null
) {
    companion object {
        fun fromJson(json: JSONObject): ExploreMoreConfig {
            val widgetId = json.getString("widgetId")
            val title = json.optString("title", "Keep on reading")
            val frequencyCapping = if (json.has("frequencyCapping")) {
                FrequencyCapping.fromJson(json.getJSONObject("frequencyCapping"))
            } else null

            return ExploreMoreConfig(
                widgetId = widgetId,
                title = title,
                frequencyCapping = frequencyCapping
            )
        }
    }
}

/**
 * How often the Explore More sheet is allowed to appear.
 *
 * | Your article surface | Use |
 * | --- | --- |
 * | One route per article | [OncePerArticle] |
 * | One long-lived screen serving many URLs (a WebView browser) | [OncePerArticle] or [OncePerSession] |
 * | You want one sheet per sitting, whatever the reader reads | [OncePerSession] |
 * | You want a wall-clock throttle that ignores sittings | [every] |
 * | Development and demos | [EveryTime] |
 *
 * **What "session" means here:** a browsing session — a sliding window of activity that ends
 * after 30 minutes with no back press for the SDK to evaluate. It is *not* the lifetime of
 * the OS process. Backgrounding the app and returning a minute later continues the same
 * session; coming back tomorrow starts a new one; being killed for memory in between changes
 * nothing, because the window is persisted rather than held in memory.
 *
 * [OncePerSession] and [OncePerArticle] are both scoped to that window, so neither can cap a
 * reader permanently. [Custom]/[every] are the exception, and deliberately so: they are a
 * wall-clock throttle measured across sessions.
 */
sealed class FrequencyCapping {

    /**
     * Shows at most once per browsing session, whatever the reader reads in it.
     *
     * The strictest mode that still recovers on its own: a reader who comes back after the
     * 30-minute idle window is eligible again. A safe default when you are unsure.
     */
    data object OncePerSession : FrequencyCapping()

    /**
     * Shows at most once per distinct article URL **per browsing session**.
     *
     * So a reader who works through five articles in one sitting can see the sheet up to five
     * times, once each, and backing out of the same article twice only shows it once. The next
     * session starts clean.
     *
     * Give it the article URL: pass `articleUrl` to the article scaffold/helper, or
     * `articleId` to [com.revcontent.sdk.RevcontentExploreMore.presentIfNeeded].
     *
     * Without one, the screen-scoped entry points fall back to capping once per scaffold or
     * helper *instance* — weaker than per-article-per-session, since a fresh screen starts
     * over, but far better than prompting on every back press. They log a warning either way.
     * [com.revcontent.sdk.RevcontentExploreMore.presentIfNeeded] has no instance to fall back
     * to, so there the id is effectively required.
     *
     * One thing to get right: the URL is the identity, so query strings count. If yours carry
     * tracking parameters (`?utm_source=…`) or cache-busters, strip the query and fragment
     * before passing it, or one article will look like several.
     *
     * Weaker fit on an in-place WebView surface than on a one-route-per-article screen. There,
     * a back press always is an article exit; in a web view the reader can stack several
     * history entries with in-page links — which push rather than pop, even when labelled
     * "back" — and each step out is then its own prompt. See "Deep web history" in the README.
     */
    data object OncePerArticle : FrequencyCapping()

    /**
     * No capping — shows on every back press. The default when `frequencyCapping` is null.
     * Useful in development because it is predictable; usually too aggressive to ship.
     */
    data object EveryTime : FrequencyCapping()

    /**
     * Wall-clock throttle: milliseconds since the sheet was last shown, measured across
     * browsing sessions and persisted across process restarts. Prefer the [every] helper.
     */
    data class Custom(val intervalMillis: Long) : FrequencyCapping()

    companion object {
        /**
         * Time-based throttle: shows at most once per [interval] since the last
         * display, measured against wall-clock `System.currentTimeMillis()` and
         * persisted across process restarts. Compiles to [Custom] under the hood
         * — provided so call sites read naturally:
         *
         *     FrequencyCapping.every(4.hours)
         *     FrequencyCapping.every(30.minutes)
         */
        fun every(interval: Duration): FrequencyCapping = Custom(interval.inWholeMilliseconds)

        fun fromJson(json: JSONObject): FrequencyCapping {
            return when (json.optString("type", "everyTime")) {
                "oncePerSession" -> OncePerSession
                "oncePerArticle" -> OncePerArticle
                "everyTime" -> EveryTime
                "custom" -> Custom(json.optLong("interval", 0L))
                else -> EveryTime
            }
        }
    }
}