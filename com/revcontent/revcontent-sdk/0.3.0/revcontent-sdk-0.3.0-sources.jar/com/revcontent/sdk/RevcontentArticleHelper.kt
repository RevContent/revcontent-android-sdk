package com.revcontent.sdk

import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.core.widget.NestedScrollView
import androidx.lifecycle.lifecycleScope
import com.revcontent.sdk.internal.IntegrationDiagnostics
import com.revcontent.sdk.logging.SdkLog
import com.revcontent.sdk.models.ExploreMoreConfig
import com.revcontent.sdk.models.FrequencyCapping
import com.revcontent.sdk.services.ExploreMoreFrequencyManager
import com.revcontent.sdk.services.RevcontentScrollTracker
import com.revcontent.sdk.views.ExploreMoreSheet
import com.revcontent.sdk.views.RevcontentWebView
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * View-based helper that attaches Explore More back interception and scroll tracking
 * to a legacy Activity. **Compose users should prefer
 * [com.revcontent.sdk.compose.RevcontentArticleScaffold] instead.**
 *
 * `publisherId` and `siteUrl` default to whatever was set via [Revcontent.configure];
 * pass them explicitly to override.
 *
 * Typical Activity usage:
 *
 *   override fun onCreate(savedInstanceState: Bundle?) {
 *       super.onCreate(savedInstanceState)
 *       setContentView(R.layout.activity_article)
 *       RevcontentArticleHelper(
 *           activity = this,
 *           articleUrl = "https://example.com/articles/123",
 *           webView = findViewById(R.id.revcontent_widget),
 *           scrollView = findViewById(R.id.scroll_view),
 *           exploreMoreConfig = ExploreMoreConfig(
 *               widgetId = "286827",
 *               frequencyCapping = FrequencyCapping.OncePerArticle
 *           )
 *       ).attach()
 *   }
 */
class RevcontentArticleHelper(
    private val activity: ComponentActivity,
    private val articleUrl: String? = null,
    private val webView: RevcontentWebView? = null,
    private val scrollView: NestedScrollView? = null,
    private val throttleMs: Long = 100L,
    private val exploreMoreConfig: ExploreMoreConfig? = null,
    private val publisherId: String = Revcontent.publisherId,
    private val siteUrl: String = Revcontent.siteUrl,
    private val onNavigateBack: (() -> Unit)? = null
) {
    private var activeSheet: ExploreMoreSheet? = null
    private val frequencyManager = ExploreMoreFrequencyManager.getInstance(activity)

    /**
     * Fallback identity for [FrequencyCapping.OncePerArticle] when no [articleUrl] is given.
     * One helper is constructed per article screen, so "already shown by this instance" stands
     * in for "already shown for this article".
     */
    private var hasShownInThisArticle = false

    private val backCallback = object : OnBackPressedCallback(enabled = false) {
        override fun handleOnBackPressed() {
            val config = exploreMoreConfig ?: return navigateBack()
            val shouldShow = com.revcontent.sdk.internal.shouldShowExploreMore(
                config = config,
                articleUrl = articleUrl,
                state = frequencyManager,
                isSheetShowing = activeSheet?.isShowing() == true,
                hasShownInThisInstance = hasShownInThisArticle
            )
            if (shouldShow) {
                showExploreMore(config)
            } else {
                navigateBack()
            }
        }
    }

    /**
     * Call this from Activity.onCreate() after setContentView(),
     * or from a Compose DisposableEffect.
     */
    fun attach() {
        if (exploreMoreConfig != null) {
            if (exploreMoreConfig.frequencyCapping is FrequencyCapping.OncePerArticle && articleUrl == null) {
                SdkLog.w {
                    "OncePerArticle requested but no articleUrl provided; falling back to once " +
                        "per helper instance. Pass articleUrl to cap per article across the session."
                }
            }
            backCallback.isEnabled = true
            activity.onBackPressedDispatcher.addCallback(activity, backCallback)
        }

        if (webView != null && scrollView != null) {
            RevcontentScrollTracker(
                context = activity,
                webView = webView,
                throttleMs = throttleMs
            ).attachToNestedScrollView(scrollView)
        } else if (webView != null) {
            IntegrationDiagnostics.warnOnce("helper-missing-scroll-view:${activity.javaClass.name}") {
                "RevcontentArticleHelper was given a webView but no scrollView. Without one the " +
                    "widget never receives the host's scroll geometry, so it treats itself as " +
                    "fully on screen from the moment it loads and reports impressions for views " +
                    "that never happened. Pass the NestedScrollView the widget scrolls inside:\n" +
                    "    RevcontentArticleHelper(activity = this, webView = ..., " +
                    "scrollView = findViewById(R.id.scroll_view)).attach()"
            }
        } else if (scrollView != null) {
            IntegrationDiagnostics.warnOnce("helper-missing-web-view:${activity.javaClass.name}") {
                "RevcontentArticleHelper was given a scrollView but no webView, so no widget is " +
                    "receiving scroll geometry and any widget on this screen will report " +
                    "impressions for views that never happened. Pass the RevcontentWebView the " +
                    "scrollView contains:\n" +
                    "    RevcontentArticleHelper(activity = this, " +
                    "webView = findViewById(R.id.revcontent_widget), scrollView = ...).attach()"
            }
        }
    }

    private fun showExploreMore(config: ExploreMoreConfig) {
        hasShownInThisArticle = true
        val sheet = ExploreMoreSheet(
            context = activity,
            config = config,
            publisherId = publisherId,
            siteUrl = siteUrl,
            onDismiss = {
                activeSheet = null
                frequencyManager.markShown(articleUrl)
                // Let the sheet's slide-out animation play before tearing down the screen behind it.
                activity.lifecycleScope.launch {
                    delay(SHEET_DISMISS_ANIMATION_MS)
                    navigateBack()
                }
            },
            onArticleClick = {
                frequencyManager.markShown(articleUrl)
            }
        )

        activeSheet = sheet
        sheet.show()
    }

    private fun navigateBack() {
        backCallback.isEnabled = false
        val callback = onNavigateBack
        if (callback != null) {
            callback()
        } else {
            activity.onBackPressedDispatcher.onBackPressed()
        }
    }

    companion object {
        private const val SHEET_DISMISS_ANIMATION_MS = 150L
    }
}
