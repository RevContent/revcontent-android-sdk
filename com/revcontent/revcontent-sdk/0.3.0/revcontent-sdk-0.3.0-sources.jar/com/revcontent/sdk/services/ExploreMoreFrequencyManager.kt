package com.revcontent.sdk.services

import android.content.Context
import android.content.SharedPreferences
import androidx.annotation.VisibleForTesting
import com.revcontent.sdk.internal.FrequencyState

/**
 * Frequency-capping state for Explore More, scoped to a **browsing session**.
 *
 * A session is a sliding window of activity: it starts on the first back press the SDK is
 * consulted about and ends after [SESSION_TIMEOUT_MS] with no further ones. Every
 * consultation extends it, so a reader who keeps browsing stays in one session no matter how
 * long they read.
 *
 * The definition is deliberately **not** "the lifetime of the OS process", which is what this
 * class used to mean by session. Process lifetime is invisible to the reader and wrong in both
 * directions: an app backgrounded for hours and resumed is still the same process, while an app
 * killed for memory after thirty seconds looks like a brand-new one. Anchoring on inactivity
 * instead makes a session mean what a publisher means by it, and makes the behaviour survive
 * process death — the window is persisted, not held in memory.
 *
 * Session scope is also what bounds the shown-article set: it is cleared whenever a new session
 * starts, so it can only ever hold the articles read in one sitting. An earlier version kept it
 * for the life of the install, which capped `OncePerArticle` permanently and grew without limit.
 *
 * [canShowAfter] is the exception — a [com.revcontent.sdk.models.FrequencyCapping.Custom]
 * interval is an explicit wall-clock throttle and is measured independently of sessions.
 */
class ExploreMoreFrequencyManager private constructor(context: Context) : FrequencyState {

    private val prefs: SharedPreferences = context.getSharedPreferences(
        PREFS_NAME,
        Context.MODE_PRIVATE
    )

    /** Test seam, mirroring `RevcontentScrollTracker.clock`, so session expiry is drivable. */
    @VisibleForTesting
    internal var clock: () -> Long = System::currentTimeMillis

    companion object {
        private const val PREFS_NAME = "revcontent_explore_more_prefs"

        /** Wall-clock time the sheet was last shown. Session-independent; backs `Custom`. */
        private const val KEY_LAST_SHOWN_TIMESTAMP = "explore_more_last_shown_timestamp"

        /** Last time the SDK was consulted. The sliding anchor the session window hangs off. */
        private const val KEY_LAST_INTERACTION = "explore_more_last_interaction"

        /** Whether the sheet has been shown in the current session. */
        private const val KEY_SESSION_SHOWN = "explore_more_session_shown"

        /** Articles shown in the current session. Cleared on rollover, so bounded by one sitting. */
        private const val KEY_SESSION_ARTICLE_URLS = "explore_more_session_article_urls"

        /**
         * Idle time that ends a browsing session. Thirty minutes is the web-analytics
         * convention (Google Analytics and friends use the same figure), so publishers
         * reading their Revcontent numbers next to their site analytics see sessions
         * counted the same way.
         */
        @VisibleForTesting
        internal const val SESSION_TIMEOUT_MS: Long = 30 * 60 * 1000L

        @Volatile
        private var instance: ExploreMoreFrequencyManager? = null

        fun getInstance(context: Context): ExploreMoreFrequencyManager {
            return instance ?: synchronized(this) {
                instance ?: ExploreMoreFrequencyManager(context.applicationContext).also {
                    instance = it
                }
            }
        }

        @VisibleForTesting
        internal fun resetForTesting() {
            synchronized(this) { instance = null }
        }
    }

    override fun wasShownThisSession(): Boolean {
        noteInteraction()
        return prefs.getBoolean(KEY_SESSION_SHOWN, false)
    }

    override fun wasShownForArticle(articleUrl: String): Boolean {
        noteInteraction()
        return articleUrl in sessionArticleUrls()
    }

    override fun canShowAfter(intervalMillis: Long): Boolean {
        noteInteraction()
        val lastShown = prefs.getLong(KEY_LAST_SHOWN_TIMESTAMP, 0L)
        if (lastShown == 0L) return true
        return clock() - lastShown >= intervalMillis
    }

    fun markShown(articleUrl: String? = null) {
        noteInteraction()
        prefs.edit().apply {
            putLong(KEY_LAST_SHOWN_TIMESTAMP, clock())
            putBoolean(KEY_SESSION_SHOWN, true)
            if (articleUrl != null) {
                putStringSet(KEY_SESSION_ARTICLE_URLS, sessionArticleUrls() + articleUrl)
            }
            apply()
        }
    }

    /**
     * Records that the reader is active, rolling over to a fresh session first if the previous
     * one has gone idle. Called from every read as well as from [markShown]: the SDK is only
     * ever consulted on a back press, so a consultation *is* activity, and treating it as such
     * is what makes the window slide.
     *
     * A missing anchor means either a first run or an upgrade from the process-lifetime scheme,
     * and both should start clean rather than inherit whatever the old keys held.
     */
    private fun noteInteraction() {
        val now = clock()
        val lastInteraction = prefs.getLong(KEY_LAST_INTERACTION, 0L)
        val startingNewSession = lastInteraction == 0L || now - lastInteraction >= SESSION_TIMEOUT_MS

        prefs.edit().apply {
            if (startingNewSession) {
                putBoolean(KEY_SESSION_SHOWN, false)
                putStringSet(KEY_SESSION_ARTICLE_URLS, emptySet())
            }
            putLong(KEY_LAST_INTERACTION, now)
            apply()
        }
    }

    // getStringSet returns an unmodifiable instance the caller must not mutate — copy on write.
    private fun sessionArticleUrls(): Set<String> =
        prefs.getStringSet(KEY_SESSION_ARTICLE_URLS, emptySet()) ?: emptySet()
}
