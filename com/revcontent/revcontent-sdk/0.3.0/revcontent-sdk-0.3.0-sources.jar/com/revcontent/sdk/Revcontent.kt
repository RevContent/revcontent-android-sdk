package com.revcontent.sdk

import androidx.annotation.VisibleForTesting
import com.revcontent.sdk.logging.LogLevel
import com.revcontent.sdk.logging.RevcontentLogger
import com.revcontent.sdk.logging.SdkLog

/**
 * App-wide entry point for the Revcontent Android SDK.
 *
 * Call [configure] once from your `Application.onCreate()`:
 *
 *     class MyApplication : Application() {
 *         override fun onCreate() {
 *             super.onCreate()
 *             Revcontent.configure(
 *                 publisherId = "84088",
 *                 siteUrl = "https://app.revcontent.com",
 *                 logger = LogcatLogger(),     // optional, default: silent
 *                 logLevel = LogLevel.DEBUG,   // optional
 *             )
 *         }
 *     }
 *
 * After that, composables like [com.revcontent.sdk.compose.RevcontentWidget] and
 * [com.revcontent.sdk.compose.RevcontentArticleScaffold] pick up the publisher
 * defaults automatically. Per-call overrides are still supported when you need
 * to embed widgets from more than one publisher.
 */
object Revcontent {

    @Volatile
    private var _publisherId: String? = null

    @Volatile
    private var _siteUrl: String? = null

    /** The configured publisher id. Throws if [configure] has not been called. */
    val publisherId: String
        get() = _publisherId
            ?: error("Revcontent.configure(...) was never called. Invoke it from Application.onCreate().")

    /** The configured site URL. Throws if [configure] has not been called. */
    val siteUrl: String
        get() = _siteUrl
            ?: error("Revcontent.configure(...) was never called. Invoke it from Application.onCreate().")

    /** True once [configure] has been called. */
    val isConfigured: Boolean
        get() = _publisherId != null && _siteUrl != null

    /**
     * Base URL the widget `widget.js` bundle is loaded from. Defaults to the
     * production delivery host. Exposed only so instrumented screenshot tests can
     * point the WebView at a deterministic local stub server (MockWebServer);
     * production code never reassigns it.
     */
    @get:VisibleForTesting
    @set:VisibleForTesting
    @Volatile
    var deliveryBaseUrl: String = "https://delivery.revcontent.com"

    /**
     * Sets the publisher defaults used by widgets that don't pass them explicitly,
     * and optionally attaches a logger so the SDK emits during development.
     *
     * Safe to call more than once (the latest values win) but typically called once at app start.
     */
    @JvmStatic
    @JvmOverloads
    fun configure(
        publisherId: String,
        siteUrl: String,
        logger: RevcontentLogger? = null,
        logLevel: LogLevel = LogLevel.DEBUG,
    ) {
        require(publisherId.isNotBlank()) { "publisherId must not be blank" }
        require(siteUrl.isNotBlank()) { "siteUrl must not be blank" }
        _publisherId = publisherId
        _siteUrl = siteUrl
        SdkLog.logger = logger
        SdkLog.minLevel = logLevel
    }

    /** Attach a sink so the SDK emits. Pass null to detach and go silent (the default). */
    @JvmStatic
    @JvmOverloads
    fun setLogger(logger: RevcontentLogger?, minLevel: LogLevel = LogLevel.DEBUG) {
        SdkLog.logger = logger
        SdkLog.minLevel = minLevel
    }

    /** Adjust verbosity without detaching the sink. */
    @JvmStatic
    fun setLogLevel(level: LogLevel) {
        SdkLog.minLevel = level
    }

    /** Override the tag handed to the sink (default "RevcontentSDK"). */
    @JvmStatic
    fun setLogTag(tag: String) {
        SdkLog.tag = tag
    }
}
