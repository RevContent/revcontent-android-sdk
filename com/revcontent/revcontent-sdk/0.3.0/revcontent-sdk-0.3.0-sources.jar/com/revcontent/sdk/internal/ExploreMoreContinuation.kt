package com.revcontent.sdk.internal

import java.util.concurrent.atomic.AtomicReference

/**
 * The host app's own "back" action, held until the Explore More sheet finishes.
 *
 * Used by [com.revcontent.sdk.RevcontentExploreMore], where four separate paths can want
 * to hand control back to the caller — capping declined, presentation failed, the sheet
 * was dismissed, or the Activity was destroyed. Exactly one of them may win.
 *
 * Clear-then-call rather than a `hasRun` flag: nulling the reference *before* invoking is
 * what makes it exactly-once even if the block re-enters, and it drops the SDK's hold on a
 * lambda that almost always captures the host Activity and its WebView. A flag set after
 * the call would give the first property and not the second.
 */
internal class ExploreMoreContinuation(continuation: () -> Unit) {

    private val pending = AtomicReference<(() -> Unit)?>(continuation)

    /** True while the host's action is still owed. */
    val isPending: Boolean get() = pending.get() != null

    /** Runs the host's action if it hasn't run yet. Returns whether it ran. */
    fun complete(): Boolean {
        val block = pending.getAndSet(null) ?: return false
        block()
        return true
    }

    /**
     * Drops the host's action **without** running it, for when the Activity that owns the
     * back action is gone — the block would drive a WebView that no longer exists.
     * Returns whether there was one to drop.
     */
    fun abandon(): Boolean = pending.getAndSet(null) != null
}
