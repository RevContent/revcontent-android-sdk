package com.revcontent.sdk.views

import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.os.Build
import android.util.AttributeSet
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature
import com.revcontent.sdk.Revcontent
import com.revcontent.sdk.internal.buildWidgetHtml
import com.revcontent.sdk.internal.normalizeBackgroundColorHex

/**
 * Custom WebView that handles Revcontent widget rendering and communication
 */
@SuppressLint("SetJavaScriptEnabled")
class RevcontentWebView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : WebView(context, attrs, defStyleAttr) {

    var onHeightChanged: ((Float) -> Unit)? = null
    var onLinkClicked: ((String) -> Unit)? = null
    var onScrollChange: ((Int) -> Unit)? = null
    var onLoaded: (() -> Unit)? = null
    var onError: ((String) -> Unit)? = null

    override fun onScrollChanged(l: Int, t: Int, oldl: Int, oldt: Int) {
        super.onScrollChanged(l, t, oldl, oldt)
        onScrollChange?.invoke(t)
    }

    private var widgetId: String = ""
    private var publisherId: String = ""
    private var siteUrl: String = ""
    private var backgroundColorHex: String? = null

    init {
        setupWebView()
        // Only expose this WebView to chrome://inspect when the host app itself is debuggable.
        if ((context.applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0) {
            setWebContentsDebuggingEnabled(true)
        }
    }

    private fun setupWebView() {
settings.apply {
    javaScriptEnabled = true
    domStorageEnabled = true
    loadWithOverviewMode = true
    useWideViewPort = true
    // Compatibility mode blocks high-risk mixed content (scripts, stylesheets)
    // but still permits low-risk subresources (images/pixels). The widget JS
    // fires stats pixels which may not all be HTTPS on legacy publisher hosts;
    // COMPATIBILITY_MODE keeps those working while closing the script-injection
    // surface that MIXED_CONTENT_ALWAYS_ALLOW leaves open.
    mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
    // The widget JS bundle reflects server-side publisher settings; caching it
    // would delay config changes from taking effect on the device. Stats pixels
    // are independent network calls and aren't affected by this setting.
    cacheMode = WebSettings.LOAD_NO_CACHE
}

        if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
            WebSettingsCompat.setAlgorithmicDarkeningAllowed(settings, true)
        } else if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK)) {
            @Suppress("DEPRECATION")
            WebSettingsCompat.setForceDark(settings, WebSettingsCompat.FORCE_DARK_AUTO)
        }

        // Add JavaScript interface for communication
        addJavascriptInterface(WebAppInterface(), "Android")

        // Set WebView client for navigation handling
        webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                onLoaded?.invoke()
            }

            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
            ): Boolean = interceptUrl(request?.url?.toString())

            // Fallback for API < 24 where the WebResourceRequest overload isn't invoked.
            @Deprecated("Kept for API 21-23 compatibility; the WebResourceRequest overload is preferred.")
            @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) return false
                return interceptUrl(url)
            }

            private fun interceptUrl(url: String?): Boolean {
                if (url == null) return false
                onLinkClicked?.invoke(url)
                return true
            }
        }
    }

    /**
     * Loads the widget. `publisherId` and `siteUrl` default to the values set via
     * [Revcontent.configure]; pass them explicitly to override.
     *
     * `backgroundColorHex` (a CSS #RRGGBB string) is baked into the document body and applied
     * to the WebView canvas so the widget matches a known host surface from the first paint.
     * When null, both the WebView and the document body go fully transparent, letting the
     * host view's background show through.
     */
    @JvmOverloads
    fun loadWidget(
        widgetId: String,
        publisherId: String = Revcontent.publisherId,
        siteUrl: String = Revcontent.siteUrl,
        backgroundColorHex: String? = null
    ) {
        this.widgetId = widgetId
        this.publisherId = publisherId
        this.siteUrl = siteUrl
        this.backgroundColorHex = normalizeBackgroundColorHex(backgroundColorHex)

        setBackgroundColor(this.backgroundColorHex?.let(Color::parseColor) ?: Color.TRANSPARENT)

        loadDataWithBaseURL(
            siteUrl,
            buildWidgetHtml(widgetId, publisherId, siteUrl, this.backgroundColorHex, Revcontent.deliveryBaseUrl),
            "text/html",
            "UTF-8",
            null
        )
    }

    /**
     * JavaScript interface for WebView communication
     */
    inner class WebAppInterface {
        @JavascriptInterface
        fun onHeightChange(height: Float) {
            post {
                onHeightChanged?.invoke(height)
            }
        }
    }
}