package com.revcontent.sdk.internal

/**
 * Pure (Android-free) helpers for assembling the widget document.
 *
 * Kept out of [com.revcontent.sdk.views.RevcontentWebView] so the HTML
 * assembly, id escaping, and background-color validation are unit-testable
 * on the JVM without a WebView / Robolectric.
 */

private val BG_COLOR_HEX = Regex("^#[0-9A-Fa-f]{6}$")

/**
 * Returns [raw] when it is a valid CSS `#RRGGBB` string, otherwise null.
 * Anything that isn't an exact 6-digit hex color (3-digit shorthand, 8-digit
 * with alpha, named colors, missing `#`, stray whitespace) is rejected so it
 * can fall back to a transparent canvas rather than being injected verbatim.
 */
internal fun normalizeBackgroundColorHex(raw: String?): String? =
    raw?.takeIf { it.matches(BG_COLOR_HEX) }

/**
 * Builds the widget document. Ids are HTML-attribute-escaped where they land
 * in attributes and percent-encoded where they land in the script URL path, so
 * a hostile widget/publisher id cannot break out of its context.
 *
 * [backgroundColorHex] is expected to already be normalized via
 * [normalizeBackgroundColorHex]; when null the body goes transparent.
 *
 * [deliveryBaseUrl] is the origin the `widget.js` loader is served from; it
 * defaults to production so existing callers/tests are unaffected, but
 * `RevcontentWebView` passes `Revcontent.deliveryBaseUrl` so a host can point
 * the SDK at a non-prod delivery environment.
 */
internal fun buildWidgetHtml(
    widgetId: String,
    publisherId: String,
    siteUrl: String,
    backgroundColorHex: String?,
    deliveryBaseUrl: String = "https://delivery.revcontent.com"
): String {
    val safeWidgetId = htmlAttrEscape(widgetId)
    val safePublisherId = htmlAttrEscape(publisherId)
    val safeSiteUrl = htmlAttrEscape(siteUrl)

    val urlWidgetId = urlPathEscape(widgetId)
    val urlPublisherId = urlPathEscape(publisherId)
    val bg = backgroundColorHex ?: "transparent"

    return """
        <!DOCTYPE html>
        <html>
        <head>
            <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
            <meta name="color-scheme" content="light dark">
            <script>window.__revcontent = { sdk: true, platform: 'android' };</script>
            <style>
                html, body {
                    margin: 0;
                    background: $bg;
                    padding: 0;
                    overflow-x: hidden;
                    font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
                }
            </style>
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    const resizeObserver = new ResizeObserver(entries => {
                        for (let entry of entries) {
                            const height = entry.contentRect.height || document.body.scrollHeight;
                            Android.onHeightChange(height);
                        }
                    });
                    resizeObserver.observe(document.body);

                    window.addEventListener('load', function() {
                        Android.onHeightChange(document.body.scrollHeight);
                    });
                });
            </script>
        </head>
        <body>
            <div id="app" data-widget-host="revcontent"
                 data-widget-id="$safeWidgetId"
                 data-pub-id="$safePublisherId"
                 data-site-url="$safeSiteUrl">
            </div>
            <script src="$deliveryBaseUrl/$urlPublisherId/$urlWidgetId/widget.js"></script>
        </body>
        </html>
    """.trimIndent()
}
