package com.revcontent.sdk.internal

import com.revcontent.sdk.models.ExploreMoreConfig
import com.revcontent.sdk.models.FrequencyCapping

/**
 * Minimal read-only view of frequency-capping state. Implemented by
 * `ExploreMoreFrequencyManager` in production; can be faked in tests.
 */
internal interface FrequencyState {
    /** Whether the sheet has shown in the current browsing session (a 30-minute idle window). */
    fun wasShownThisSession(): Boolean

    /** Whether the sheet has shown for this URL **in the current session**. */
    fun wasShownForArticle(articleUrl: String): Boolean

    /** Whether [intervalMillis] of wall-clock time has passed since the last display. */
    fun canShowAfter(intervalMillis: Long): Boolean
}

/**
 * Pure decision function — given the current capping config, article URL,
 * frequency state, and whether a sheet is already on screen, returns whether
 * the Explore More sheet should be displayed in response to a back press.
 *
 * @param hasShownInThisInstance Whether the caller has already shown the sheet during its own
 *   lifetime. Only consulted for [FrequencyCapping.OncePerArticle] when [articleUrl] is null,
 *   as the fallback identity: a screen that cannot name its article can still recognise that
 *   *it* has already prompted. Screen-scoped callers (the article scaffold and helper) hold
 *   this per instance; the imperative path has no instance to scope to and passes `false`,
 *   which is why it warns instead. Matches the iOS SDK, where the SwiftUI modifier and the
 *   UIKit coordinator each keep a `hasShownInThisArticle` flag.
 */
internal fun shouldShowExploreMore(
    config: ExploreMoreConfig,
    articleUrl: String?,
    state: FrequencyState,
    isSheetShowing: Boolean,
    hasShownInThisInstance: Boolean = false
): Boolean {
    if (isSheetShowing) return false

    return when (val capping = config.frequencyCapping) {
        null,
        FrequencyCapping.EveryTime -> true
        FrequencyCapping.OncePerSession -> !state.wasShownThisSession()
        // With a URL this caps per article per session. Without one, fall back to the
        // caller's own lifetime rather than giving up and showing every time — a sheet on
        // every back press is a worse answer to a missing id than capping conservatively.
        FrequencyCapping.OncePerArticle ->
            articleUrl?.let { !state.wasShownForArticle(it) } ?: !hasShownInThisInstance
        is FrequencyCapping.Custom -> state.canShowAfter(capping.intervalMillis)
    }
}

/** Why the imperative path did or didn't present. Each non-[PRESENT] value logs differently. */
internal enum class ExploreMoreGate {
    PRESENT,
    NOT_CONFIGURED,
    CAPPED,
    ALREADY_PRESENTING,

    /**
     * The caller told us this back press moves within their content rather than leaving it —
     * an in-place WebView stepping back through its own history, say. Not a misconfiguration
     * and not a cap: the reader has not finished with the surface yet, so there is nothing to
     * offer them. Deliberately checked before capping so it never consumes one.
     */
    NOT_SURFACE_EXIT,
}

/**
 * The four-way verdict for [com.revcontent.sdk.RevcontentExploreMore.presentIfNeeded].
 *
 * Deliberately *not* a second decision table: it delegates the capping question to
 * [shouldShowExploreMore], the same function the back-press paths use, and differs only in
 * where the per-article term comes from — a caller-supplied id rather than a per-instance
 * flag, because one Activity serves every article on the imperative path.
 *
 * Capping is evaluated before [isAlreadyPresenting] to match the iOS ordering, and
 * `isSheetShowing = false` is passed through so a live sheet surfaces as
 * [ExploreMoreGate.ALREADY_PRESENTING] rather than being folded into [ExploreMoreGate.CAPPED] —
 * the two want different log lines.
 */
internal fun exploreMoreGate(
    isConfigured: Boolean,
    isAlreadyPresenting: Boolean,
    isSurfaceExit: Boolean,
    config: ExploreMoreConfig,
    articleId: String?,
    state: FrequencyState
): ExploreMoreGate = when {
    !isConfigured -> ExploreMoreGate.NOT_CONFIGURED
    // Ahead of the capping check on purpose: a back press the caller has told us stays
    // inside their content must not spend a cap it never got the chance to use.
    !isSurfaceExit -> ExploreMoreGate.NOT_SURFACE_EXIT
    // hasShownInThisInstance is false by design: this path is a bare function call with no
    // instance to scope to, so a missing articleId genuinely cannot cap. The caller warns.
    !shouldShowExploreMore(config, articleId, state, isSheetShowing = false) -> ExploreMoreGate.CAPPED
    isAlreadyPresenting -> ExploreMoreGate.ALREADY_PRESENTING
    else -> ExploreMoreGate.PRESENT
}
