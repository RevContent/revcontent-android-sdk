package com.revcontent.sdk.services

import android.content.Context
import android.content.SharedPreferences
import androidx.annotation.VisibleForTesting
import com.revcontent.sdk.internal.FrequencyState

/**
 * Manages frequency capping for the Explore More feature.
 *
 * A "session" is defined as the lifetime of the OS process. The session window is anchored
 * to the time this singleton is first constructed; no setup call is required from the publisher.
 */
class ExploreMoreFrequencyManager private constructor(context: Context) : FrequencyState {

    private val prefs: SharedPreferences = context.getSharedPreferences(
        PREFS_NAME,
        Context.MODE_PRIVATE
    )

    companion object {
        private const val PREFS_NAME = "revcontent_explore_more_prefs"
        private const val KEY_LAST_SHOWN_TIMESTAMP = "explore_more_last_shown_timestamp"
        private const val KEY_SHOWN_ARTICLE_URLS = "explore_more_shown_article_urls"

        // Anchored once per process. Compared against the wall-clock lastShown timestamp
        // to decide whether the most recent display was "this session."
        @JvmStatic
        @VisibleForTesting
        internal var sessionStartTimestamp: Long = System.currentTimeMillis()

        @Volatile
        private var instance: ExploreMoreFrequencyManager? = null

        fun getInstance(context: Context): ExploreMoreFrequencyManager {
            return instance ?: synchronized(this) {
                instance ?: ExploreMoreFrequencyManager(context.applicationContext).also {
                    instance = it
                }
            }
        }

        @VisibleForTesting
        internal fun resetForTesting() {
            synchronized(this) { instance = null }
        }
    }

    override fun wasShownThisSession(): Boolean {
        val lastShown = prefs.getLong(KEY_LAST_SHOWN_TIMESTAMP, 0L)
        return lastShown >= sessionStartTimestamp
    }

    override fun wasShownForArticle(articleUrl: String): Boolean {
        val shown = prefs.getStringSet(KEY_SHOWN_ARTICLE_URLS, emptySet()) ?: emptySet()
        return articleUrl in shown
    }

    override fun canShowAfter(intervalMillis: Long): Boolean {
        val lastShown = prefs.getLong(KEY_LAST_SHOWN_TIMESTAMP, 0L)
        if (lastShown == 0L) return true
        return System.currentTimeMillis() - lastShown >= intervalMillis
    }

    fun markShown(articleUrl: String? = null) {

        prefs.edit().apply {
            putLong(KEY_LAST_SHOWN_TIMESTAMP, System.currentTimeMillis())
            if (articleUrl != null) {
                val shown = prefs.getStringSet(KEY_SHOWN_ARTICLE_URLS, emptySet()) ?: emptySet()
                // getStringSet returns an unmodifiable instance — copy before mutating.
                putStringSet(KEY_SHOWN_ARTICLE_URLS, shown + articleUrl)
            }
            apply()
        }
    }

}
