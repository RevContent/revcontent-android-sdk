package com.revcontent.sdk.internal

import com.revcontent.sdk.models.ExploreMoreConfig
import com.revcontent.sdk.models.FrequencyCapping

/**
 * Minimal read-only view of frequency-capping state. Implemented by
 * `ExploreMoreFrequencyManager` in production; can be faked in tests.
 */
internal interface FrequencyState {
    fun wasShownThisSession(): Boolean
    fun wasShownForArticle(articleUrl: String): Boolean
    fun canShowAfter(intervalMillis: Long): Boolean
}

/**
 * Pure decision function — given the current capping config, article URL,
 * frequency state, and whether a sheet is already on screen, returns whether
 * the Explore More sheet should be displayed in response to a back press.
 *
 * If [FrequencyCapping.OncePerArticle] is requested without an [articleUrl] the
 * function falls back to "always show" (a misconfiguration the scaffold should
 * also log once at setup time).
 */
internal fun shouldShowExploreMore(
    config: ExploreMoreConfig,
    articleUrl: String?,
    state: FrequencyState,
    isSheetShowing: Boolean
): Boolean {
    if (isSheetShowing) return false

    return when (val capping = config.frequencyCapping) {
        null,
        FrequencyCapping.EveryTime -> true
        FrequencyCapping.OncePerSession -> !state.wasShownThisSession()
        FrequencyCapping.OncePerArticle ->
            articleUrl?.let { !state.wasShownForArticle(it) } ?: true
        is FrequencyCapping.Custom -> state.canShowAfter(capping.intervalMillis)
    }
}
