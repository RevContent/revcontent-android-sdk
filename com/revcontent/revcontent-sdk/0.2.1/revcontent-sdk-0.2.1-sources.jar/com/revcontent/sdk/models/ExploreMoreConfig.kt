package com.revcontent.sdk.models

import org.json.JSONObject
import kotlin.time.Duration

/**
 * Configuration for the Explore More feature
 */
data class ExploreMoreConfig(
    val widgetId: String,
    val title: String = "Keep on reading",
    val frequencyCapping: FrequencyCapping? = null
) {
    companion object {
        fun fromJson(json: JSONObject): ExploreMoreConfig {
            val widgetId = json.getString("widgetId")
            val title = json.optString("title", "Keep on reading")
            val frequencyCapping = if (json.has("frequencyCapping")) {
                FrequencyCapping.fromJson(json.getJSONObject("frequencyCapping"))
            } else null

            return ExploreMoreConfig(
                widgetId = widgetId,
                title = title,
                frequencyCapping = frequencyCapping
            )
        }
    }
}

/**
 * Frequency capping options for Explore More display
 */
sealed class FrequencyCapping {
    data object OncePerSession : FrequencyCapping()
    data object OncePerArticle : FrequencyCapping()
    data object EveryTime : FrequencyCapping()
    data class Custom(val intervalMillis: Long) : FrequencyCapping()

    companion object {
        /**
         * Time-based throttle: shows at most once per [interval] since the last
         * display, measured against wall-clock `System.currentTimeMillis()` and
         * persisted across process restarts. Compiles to [Custom] under the hood
         * — provided so call sites read naturally:
         *
         *     FrequencyCapping.every(4.hours)
         *     FrequencyCapping.every(30.minutes)
         */
        fun every(interval: Duration): FrequencyCapping = Custom(interval.inWholeMilliseconds)

        fun fromJson(json: JSONObject): FrequencyCapping {
            return when (json.optString("type", "everyTime")) {
                "oncePerSession" -> OncePerSession
                "oncePerArticle" -> OncePerArticle
                "everyTime" -> EveryTime
                "custom" -> Custom(json.optLong("interval", 0L))
                else -> EveryTime
            }
        }
    }
}