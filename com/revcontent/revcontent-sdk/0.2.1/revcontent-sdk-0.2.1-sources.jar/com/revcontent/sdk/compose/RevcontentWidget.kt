package com.revcontent.sdk.compose

import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.viewinterop.AndroidView
import com.revcontent.sdk.Revcontent
import com.revcontent.sdk.internal.openLinkInCustomTab
import com.revcontent.sdk.internal.toCssHex
import com.revcontent.sdk.views.RevcontentWebView

/**
 * Renders a Revcontent widget. Self-sizes its height based on the rendered
 * content and disposes the underlying WebView when it leaves composition.
 *
 * Minimum usage (after [Revcontent.configure] has run):
 *
 *     RevcontentWidget(widgetId = "286827")
 *
 * To enable scroll-based viewability reporting, pass the enclosing scroll state:
 *
 *     val scrollState = rememberScrollState()
 *     Column(Modifier.verticalScroll(scrollState)) {
 *         // ...
 *         RevcontentWidget(widgetId = "286827", scrollState = scrollState)
 *         // ...
 *     }
 *
 * @param widgetId The Revcontent widget identifier.
 * @param modifier Modifier applied to the widget's container.
 * @param publisherId Optional override for [Revcontent.publisherId].
 * @param siteUrl Optional override for [Revcontent.siteUrl].
 * @param backgroundColor Optional opaque color baked into the widget body. When null
 *   (the default) the WebView and document body are transparent, so the host
 *   composable's background shows through. Alpha is ignored.
 * @param scrollState Optional parent scroll state; pass it for viewability tracking.
 * @param scrollThrottleMs Minimum interval between scroll-event injections.
 * @param onLoaded Invoked when the widget has finished its initial render.
 * @param onLinkClicked Invoked when the user taps a recommendation link. When null
 *   (the default), the SDK opens the URL in a Chrome Custom Tab. Pass a lambda to
 *   take over link handling entirely (e.g. analytics + your own in-app browser).
 * @param onError Invoked with an error message if widget loading fails.
 */
@Composable
fun RevcontentWidget(
    widgetId: String,
    modifier: Modifier = Modifier,
    publisherId: String = Revcontent.publisherId,
    siteUrl: String = Revcontent.siteUrl,
    backgroundColor: Color? = null,
    scrollState: ScrollState? = null,
    scrollThrottleMs: Long = 100L,
    onLoaded: () -> Unit = {},
    onLinkClicked: ((String) -> Unit)? = null,
    onError: (String) -> Unit = {}
) {
    val context = LocalContext.current
    val density = LocalDensity.current
    val densityScale = density.density

    // rememberUpdatedState so the captured WebView callbacks always invoke the
    // latest lambdas from composition instead of the ones present at first construction.
    val currentOnLoaded by rememberUpdatedState(onLoaded)
    val currentOnLinkClicked by rememberUpdatedState(onLinkClicked)
    val currentOnError by rememberUpdatedState(onError)

    var heightPx by rememberSaveable(widgetId) { mutableIntStateOf(0) }

    val backgroundColorHex = backgroundColor?.toArgb()?.toCssHex()

    val webView = remember(widgetId, publisherId, siteUrl, backgroundColorHex, densityScale) {
        RevcontentWebView(context).also { view ->
            view.onHeightChanged = { dpHeight ->
                val px = (dpHeight * densityScale).toInt()
                if (px > 0) heightPx = px
            }
            view.onLoaded = { currentOnLoaded() }
            view.onLinkClicked = { url ->
                currentOnLinkClicked?.invoke(url) ?: openLinkInCustomTab(context, url)
            }
            view.onError = { error -> currentOnError(error) }
            view.loadWidget(widgetId, publisherId, siteUrl, backgroundColorHex)
        }
    }

    DisposableEffect(webView) {
        onDispose { webView.destroy() }
    }

    val sizedModifier = modifier
        .fillMaxWidth()
        .height(with(density) { heightPx.toDp() })

    if (scrollState != null) {
        val tracker = rememberRevcontentScrollTracker(
            webView = webView,
            scrollState = scrollState,
            throttleMs = scrollThrottleMs
        )
        AndroidView(
            factory = { webView },
            modifier = sizedModifier.revcontentScrollTracker(tracker)
        )
    } else {
        AndroidView(
            factory = { webView },
            modifier = sizedModifier
        )
    }
}
