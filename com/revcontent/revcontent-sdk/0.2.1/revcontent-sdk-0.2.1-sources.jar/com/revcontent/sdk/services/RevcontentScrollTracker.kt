package com.revcontent.sdk.services

import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.annotation.VisibleForTesting
import androidx.core.view.doOnLayout
import androidx.core.widget.NestedScrollView
import com.revcontent.sdk.views.RevcontentWebView
import org.json.JSONObject

/**
 * Core scroll tracking logic shared between Compose and XML implementations.
 * Owns all intersection math and WebView injection.
 *
 * XML/View-based publishers attach this to their scroll host to get the same
 * scroll-based viewability signals the Compose path emits — either directly via
 * [attachToNestedScrollView], or with the one-line [RevcontentWebView.attachScrollTracker]
 * convenience extension. The Compose path wires this up internally; Compose
 * publishers never touch this class.
 *
 * Throttling is leading + trailing edge: the first event inside a quiet window
 * dispatches immediately, subsequent events inside [throttleMs] are coalesced
 * into one trailing dispatch so the final rest position is never dropped.
 *
 * All entry points must be called from the main thread.
 *
 * Public contract: the constructor and [attachToNestedScrollView]. The
 * intersection-math entry points ([updateViewRect], [updateViewportHeight],
 * [onScroll]) stay `internal` — they are driven by the Compose modifier within
 * the SDK and are not part of the published surface.
 *
 * @param context any Context (typically the host activity or the WebView's context).
 * @param webView the [RevcontentWebView] whose viewability tracks host scrolling.
 *   Nullable only as a unit-test seam (paired with an overridden [jsEmitter]);
 *   real publisher integrations always pass a live WebView.
 * @param throttleMs minimum gap between scroll dispatches (leading + trailing edge).
 */
class RevcontentScrollTracker(
    private val context: Context,
    private val webView: RevcontentWebView?,
    private val throttleMs: Long = 100L
) {
    private var viewRect = ViewRect()
    private var viewportHeightDp = 0f
    private var lastInjectTime = 0L

    // Indirected for tests: a fake clock and JS sink let us assert throttle
    // behavior and payload shape without a real WebView or wall clock.
    @VisibleForTesting
    internal var clock: () -> Long = { System.currentTimeMillis() }

    @VisibleForTesting
    internal var jsEmitter: (String) -> Unit = { js -> webView?.evaluateJavascript(js, null) }

    private val mainHandler = Handler(Looper.getMainLooper())
    private var pendingScrollY: Float? = null
    private val trailingRunnable = Runnable {
        val pending = pendingScrollY ?: return@Runnable
        pendingScrollY = null
        lastInjectTime = clock()
        dispatch(pending)
    }

    internal data class ViewRect(
        val x: Float = 0f,
        val y: Float = 0f,
        val width: Float = 0f,
        val height: Float = 0f
    )

    internal fun updateViewRect(x: Float, y: Float, width: Float, height: Float) {
        viewRect = ViewRect(x, y, width, height)
    }

    internal fun updateViewportHeight(heightDp: Float) {
        viewportHeightDp = heightDp
    }

    internal fun onScroll(scrollY: Float) {
        if (viewportHeightDp <= 0f) return
        val now = clock()
        val elapsed = now - lastInjectTime
        if (elapsed >= throttleMs) {
            lastInjectTime = now
            pendingScrollY = null
            mainHandler.removeCallbacks(trailingRunnable)
            dispatch(scrollY)
        } else {
            // Coalesce: keep only the latest position and schedule a single trailing fire.
            pendingScrollY = scrollY
            mainHandler.removeCallbacks(trailingRunnable)
            mainHandler.postDelayed(trailingRunnable, throttleMs - elapsed)
        }
    }

    private fun dispatch(scrollY: Float) {
        val density = context.resources.displayMetrics.density

        val rawOffset = scrollY / density
        val viewportHeight = viewportHeightDp
        val contentOffsetWithLayout = rawOffset + viewportHeight

        val isWidgetIntersecting = contentOffsetWithLayout >= viewRect.y &&
                rawOffset <= viewRect.y + viewRect.height

        val data = JSONObject().apply {
            put("contentOffset", contentOffsetWithLayout.toDouble())
            put("rawOffset", rawOffset.toDouble())
            put("isWidgetIntersecting", isWidgetIntersecting)
            put("viewRect", JSONObject().apply {
                put("x", viewRect.x.toDouble())
                put("y", viewRect.y.toDouble())
                put("width", viewRect.width.toDouble())
                put("height", viewRect.height.toDouble())
            })
        }

        val js = "document.dispatchEvent(new CustomEvent('revcontent:scroll',{detail:$data}));"

        jsEmitter(js)
    }

    /**
     * Attaches scroll tracking to a NestedScrollView for XML-based publishers.
     * Captures WebView layout position and listens for scroll changes.
     */
    fun attachToNestedScrollView(scrollView: NestedScrollView) {
        val webView = this.webView ?: return  // null only via the test constructor
        val density = context.resources.displayMetrics.density

        scrollView.addOnLayoutChangeListener { _, _, top, _, bottom, _, _, _, _ ->
            updateViewportHeight((bottom - top) / density)
        }
        scrollView.doOnLayout {
            updateViewportHeight(scrollView.height / density)
        }

        webView.doOnLayout {
            val webViewLocation = IntArray(2)
            webView.getLocationOnScreen(webViewLocation)

            val scrollLocation = IntArray(2)
            scrollView.getLocationOnScreen(scrollLocation)

            updateViewRect(
                x = (webViewLocation[0] - scrollLocation[0]) / density,
                y = (webViewLocation[1] - scrollLocation[1] + scrollView.scrollY) / density,
                width = webView.width / density,
                height = webView.height / density
            )
        }

        scrollView.setOnScrollChangeListener(NestedScrollView.OnScrollChangeListener
        { _, _, scrollY, _, _ ->
            onScroll(scrollY.toFloat())
        })
    }
}

/**
 * One-line scroll-viewability wiring for XML/View-based publishers.
 *
 * Attaches a [RevcontentScrollTracker] to [scrollView] so this widget reports the
 * same scroll-based viewability signals the Compose path emits — without pulling in
 * the [com.revcontent.sdk.RevcontentArticleHelper] article + Explore More scaffold.
 *
 * Call once after this view and [scrollView] are part of the layout (the tracker
 * defers its measurements to the next layout pass), typically alongside
 * [RevcontentWebView.loadWidget]:
 *
 * ```
 * val widget = findViewById<RevcontentWebView>(R.id.revcontent_widget)
 * widget.attachScrollTracker(findViewById(R.id.scroll_host))
 * widget.loadWidget(widgetId = "...")
 * ```
 *
 * Must be called on the main thread.
 *
 * @param scrollView the NestedScrollView host this widget scrolls within.
 * @param throttleMs minimum gap between scroll dispatches (leading + trailing edge).
 */
fun RevcontentWebView.attachScrollTracker(
    scrollView: NestedScrollView,
    throttleMs: Long = 100L
) {
    RevcontentScrollTracker(context, this, throttleMs).attachToNestedScrollView(scrollView)
}